import { EveRequest, TaskMode } from "../types/eve.js";

export const EXECUTOR_SYSTEM_PROMPT = `
Você é o núcleo de EXECUÇÃO e LÓGICA da EVE AI (perfil analítico/técnico).
Sua missão é produzir soluções concretas, precisas e operacionais para escrita, programação, análise e aprendizado.
`.trim();

export const AUDITOR_SYSTEM_PROMPT = `
Você é o núcleo de ARQUITETURA e AUDITORIA da EVE AI (perfil estrutural/revisor).
Sua missão é revisar criticamente a proposta da etapa de execução e consolidar uma resposta final clara, objetiva e pronta para uso.
`.trim();

function buildPersonalizationBlock(params: EveRequest): string {
  const p = params.personalization;
  if (!p) return "";
  const lines: string[] = [];
  if (p.profileName) lines.push(`Usuário: ${p.profileName}`);
  if (p.roleTitle) lines.push(`Perfil/Atuação: ${p.roleTitle}`);
  if (p.responseStyle) lines.push(`Estilo de resposta: ${p.responseStyle}`);
  if (p.customInstructions?.trim()) {
    lines.push(`Instruções personalizadas:\n${p.customInstructions.trim()}`);
  }
  return lines.length > 0 ? `Personalização ativa:\n${lines.join("\n")}` : "";
}

function buildMetaBlock(params: EveRequest): string {
  const lines: string[] = [];
  if (params.modelProfile) lines.push(`Modo de modelo: ${params.modelProfile}`);
  if (params.language) lines.push(`Idioma preferencial: ${params.language}`);
  if (params.enabledPlugins && params.enabledPlugins.length > 0) {
    lines.push(`Plugins ativos: ${params.enabledPlugins.join(", ")}`);
  }
  return lines.length > 0 ? `Configuração da sessão:\n${lines.join("\n")}` : "";
}

export function buildExecutorUserPrompt(params: {
  mode: TaskMode;
  prompt: string;
  context?: string;
  modelProfile?: string;
  language?: string;
  personalization?: EveRequest["personalization"];
  enabledPlugins?: string[];
}): string {
  const meta = buildMetaBlock({
    mode: params.mode,
    prompt: params.prompt,
    modelProfile: params.modelProfile,
    language: params.language,
    enabledPlugins: params.enabledPlugins,
  });
  const pers = buildPersonalizationBlock({
    mode: params.mode,
    prompt: params.prompt,
    personalization: params.personalization,
  });

  return [
    `Modo da tarefa: ${params.mode}`,
    meta || null,
    pers || null,
    params.context ? `Contexto adicional:\n${params.context}` : null,
    `Demanda:\n${params.prompt}`,
  ]
    .filter(Boolean)
    .join("\n\n");
}

export function buildAuditorUserPrompt(params: {
  mode: TaskMode;
  originalPrompt: string;
  context?: string;
  executionOutput: string;
  modelProfile?: string;
  language?: string;
  personalization?: EveRequest["personalization"];
  enabledPlugins?: string[];
}): string {
  const meta = buildMetaBlock({
    mode: params.mode,
    prompt: params.originalPrompt,
    modelProfile: params.modelProfile,
    language: params.language,
    enabledPlugins: params.enabledPlugins,
  });
  const pers = buildPersonalizationBlock({
    mode: params.mode,
    prompt: params.originalPrompt,
    personalization: params.personalization,
  });

  return [
    `Modo da tarefa: ${params.mode}`,
    meta || null,
    pers || null,
    params.context ? `Contexto adicional:\n${params.context}` : null,
    `Demanda original:\n${params.originalPrompt}`,
    `Saída da etapa de execução:\n${params.executionOutput}`,
  ]
    .filter(Boolean)
    .join("\n\n");
}
