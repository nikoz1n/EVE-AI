import "dotenv/config";
import http from "node:http";
import { EveOrchestrator } from "./core/orchestrator.js";
import { AnthropicMessagesProvider, OpenAICompatibleProvider } from "./providers/llm-provider.js";
import { MockProvider } from "./providers/mock-provider.js";
import { EveRequest, TaskMode } from "./types/eve.js";

function createEve() {
  const executorKey = process.env.EXECUTOR_API_KEY?.trim();
  const auditorKey = process.env.AUDITOR_API_KEY?.trim();

  if (!executorKey || !auditorKey) {
    return {
      modelLabel: "EVE AI · Dual Engine",
      orchestrator: new EveOrchestrator({
        executorProvider: new MockProvider("mock-openai-executor", "executor"),
        auditorProvider: new MockProvider("mock-anthropic-auditor", "auditor"),
      }),
    };
  }

  const executorModel = process.env.EXECUTOR_MODEL ?? "gpt-4o-mini";
  const auditorModel = process.env.AUDITOR_MODEL ?? "claude-3-7-sonnet-latest";

  return {
    modelLabel: `EVE AI · ${executorModel} + ${auditorModel}`,
    orchestrator: new EveOrchestrator({
      executorProvider: new OpenAICompatibleProvider({
        name: executorModel,
        apiKey: executorKey,
        baseUrl: process.env.EXECUTOR_BASE_URL ?? "https://api.openai.com/v1",
        model: executorModel,
      }),
      auditorProvider: new AnthropicMessagesProvider({
        name: auditorModel,
        apiKey: auditorKey,
        baseUrl: process.env.AUDITOR_BASE_URL ?? "https://api.anthropic.com/v1",
        model: auditorModel,
      }),
    }),
  };
}

function buildHtmlPage(modelLabel: string): string {
  return `<!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Eve AI</title>
  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Instrument+Serif:ital@0;1&family=Inter:wght@400;500;600&family=JetBrains+Mono:wght@400;500&display=swap" rel="stylesheet" />
  <style>
    :root {
      --bg-main: #fdfcf9;
      --bg-sidebar: #f8f6f0;
      --bg-surface: #ffffff;
      --bg-subtle: #f2efe8;
      --border: #e8e3d9;
      --border-strong: #ddd6c8;
      --text-primary: #1a1918;
      --text-secondary: #5c5852;
      --text-muted: #8a847b;
      --accent: #cc6624;
      --accent-soft: #e6b898;
      --accent-hover: #b35518;
    }

    * { box-sizing: border-box; }

    html, body {
      margin: 0;
      padding: 0;
      height: 100%;
      background: var(--bg-main);
      color: var(--text-primary);
      font-family: "Inter", -apple-system, BlinkMacSystemFont, sans-serif;
      -webkit-font-smoothing: antialiased;
    }

    .app {
      display: grid;
      grid-template-columns: 248px 1fr;
      height: 100vh;
      overflow: hidden;
    }

    .app.rail-closed {
      grid-template-columns: 0px 1fr;
    }

    .app.rail-closed .sidebar {
      opacity: 0;
      pointer-events: none;
      padding: 0;
      border-right: none;
    }

    /* Sidebar */
    .sidebar {
      background: var(--bg-sidebar);
      border-right: 1px solid var(--border);
      display: flex;
      flex-direction: column;
      padding: 14px 12px 12px;
      position: relative;
      transition: opacity 0.16s ease, padding 0.18s ease;
    }

    .brand-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      padding: 2px 4px 14px;
    }

    .brand-logo {
      display: flex;
      align-items: center;
      gap: 8px;
      font-size: 16px;
      font-weight: 500;
      letter-spacing: -0.01em;
      color: var(--text-primary);
    }

    .brand-asterisk {
      color: var(--accent);
      font-size: 17px;
      line-height: 1;
    }

    .icon-action {
      background: transparent;
      border: 1px solid transparent;
      color: var(--text-secondary);
      width: 28px;
      height: 28px;
      border-radius: 7px;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      font-size: 13px;
    }

    .icon-action:hover {
      background: var(--bg-subtle);
      border-color: var(--border);
      color: var(--text-primary);
    }

    .new-chat-btn {
      width: 100%;
      background: var(--bg-surface);
      border: 1px solid var(--border);
      border-radius: 9px;
      padding: 8px 12px;
      color: var(--text-primary);
      font-size: 13px;
      font-weight: 500;
      display: flex;
      align-items: center;
      gap: 9px;
      cursor: pointer;
      box-shadow: 0 1px 2px rgba(26, 25, 24, 0.03);
      margin-bottom: 10px;
    }

    .new-chat-btn:hover {
      border-color: var(--border-strong);
      background: #fffdfb;
    }

    .search-box {
      width: 100%;
      background: var(--bg-subtle);
      border: 1px solid transparent;
      border-radius: 9px;
      padding: 8px 11px;
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--text-muted);
      font-size: 12.5px;
      margin-bottom: 18px;
    }

    .search-box input {
      width: 100%;
      border: none;
      background: transparent;
      color: var(--text-primary);
      font-size: 12.5px;
      outline: none;
    }

    .search-box input::placeholder {
      color: var(--text-muted);
    }

    .section-label {
      font-size: 10.5px;
      font-weight: 600;
      letter-spacing: 0.06em;
      text-transform: uppercase;
      color: var(--text-muted);
      padding: 0 6px 8px;
    }

    .conv-list {
      flex: 1;
      overflow-y: auto;
      display: flex;
      flex-direction: column;
      gap: 2px;
    }

    .conv-empty {
      padding: 6px;
      font-size: 12.5px;
      color: var(--text-muted);
    }

    .conv-item {
      width: 100%;
      background: transparent;
      border: none;
      border-radius: 8px;
      padding: 7px 9px;
      text-align: left;
      font-size: 12.5px;
      color: var(--text-secondary);
      cursor: pointer;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .conv-item:hover {
      background: var(--bg-subtle);
      color: var(--text-primary);
    }

    .conv-item.active {
      background: #ece7dc;
      color: var(--text-primary);
      font-weight: 500;
    }

    .profile-footer {
      border-top: 1px solid var(--border);
      padding-top: 10px;
      margin-top: 8px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
      border-radius: 8px;
      padding-left: 4px;
      padding-right: 4px;
    }

    .profile-footer:hover {
      background: var(--bg-subtle);
    }

    .profile-left {
      display: flex;
      align-items: center;
      gap: 9px;
      min-width: 0;
    }

    .profile-avatar {
      width: 30px;
      height: 30px;
      border-radius: 50%;
      background: #ece8df;
      border: 1px solid var(--border-strong);
      color: var(--text-secondary);
      font-size: 11.5px;
      font-weight: 500;
      display: grid;
      place-items: center;
      flex-shrink: 0;
    }

    .profile-text {
      min-width: 0;
    }

    .profile-title {
      font-size: 12px;
      font-weight: 500;
      color: var(--text-primary);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .profile-email {
      font-size: 11px;
      color: var(--text-muted);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .chevron-up {
      color: var(--text-secondary);
      font-size: 12px;
      padding-right: 4px;
    }

    /* Account Popover Menu */
    .account-popover {
      position: fixed;
      left: 14px;
      bottom: 58px;
      width: 244px;
      background: var(--bg-surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      box-shadow: 0 12px 32px rgba(26, 25, 24, 0.14);
      padding: 6px 0;
      z-index: 80;
      display: none;
    }

    .account-popover.open {
      display: block;
    }

    .popover-email {
      padding: 8px 14px;
      font-size: 12px;
      color: var(--text-muted);
      border-bottom: 1px solid var(--border);
      margin-bottom: 4px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    .popover-item {
      width: 100%;
      background: transparent;
      border: none;
      padding: 8px 14px;
      font-size: 12.5px;
      color: var(--text-primary);
      display: flex;
      align-items: center;
      justify-content: space-between;
      text-align: left;
      cursor: pointer;
    }

    .popover-item:hover {
      background: var(--bg-subtle);
    }

    .popover-item-main {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .popover-hint {
      font-size: 11px;
      color: var(--text-muted);
    }

    .popover-sep {
      height: 1px;
      background: var(--border);
      margin: 4px 0;
    }

    /* Main Content */
    .main {
      display: flex;
      flex-direction: column;
      height: 100vh;
      min-width: 0;
      background: var(--bg-main);
    }

    .top-bar-mini {
      height: 44px;
      padding: 0 18px;
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-shrink: 0;
    }

    .scroll-main {
      flex: 1;
      overflow-y: auto;
      padding: 0 24px 20px;
    }

    .center-col {
      max-width: 680px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    /* Hero Greeting */
    .hero-block {
      padding-top: 28px;
      padding-bottom: 8px;
    }

    .hero-eyebrow {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 10.5px;
      font-weight: 600;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: var(--accent);
      margin-bottom: 10px;
    }

    .hero-heading {
      margin: 0 0 10px;
      font-family: "Instrument Serif", Georgia, serif;
      font-size: 46px;
      font-weight: 400;
      line-height: 1.08;
      letter-spacing: -0.02em;
      color: var(--text-primary);
    }

    .hero-heading em {
      font-style: italic;
      color: var(--accent);
    }

    .hero-sub {
      margin: 0;
      font-size: 14.5px;
      line-height: 1.55;
      color: var(--text-secondary);
      max-width: 540px;
    }

    /* Prompt Box */
    .prompt-card {
      background: var(--bg-surface);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 14px 16px 12px;
      box-shadow: 0 4px 16px rgba(26, 25, 24, 0.04);
    }

    .prompt-textarea {
      width: 100%;
      min-height: 54px;
      max-height: 180px;
      border: none;
      background: transparent;
      color: var(--text-primary);
      font-family: inherit;
      font-size: 14px;
      line-height: 1.5;
      resize: none;
      outline: none;
    }

    .prompt-textarea::placeholder {
      color: var(--text-muted);
    }

    .prompt-bottom {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-top: 8px;
    }

    .model-pill-btn {
      background: transparent;
      border: 1px solid transparent;
      border-radius: 8px;
      padding: 5px 8px;
      font-size: 12px;
      color: var(--text-secondary);
      display: inline-flex;
      align-items: center;
      gap: 6px;
      cursor: pointer;
    }

    .model-pill-btn:hover {
      background: var(--bg-subtle);
      color: var(--text-primary);
    }

    .model-dot {
      width: 6px;
      height: 6px;
      border-radius: 50%;
      background: var(--accent);
    }

    .send-circle {
      width: 34px;
      height: 34px;
      border-radius: 50%;
      border: none;
      background: var(--accent-soft);
      color: #ffffff;
      font-size: 15px;
      font-weight: 500;
      display: inline-flex;
      align-items: center;
      justify-content: center;
      cursor: pointer;
      transition: background 0.15s ease;
    }

    .send-circle.ready, .send-circle:hover:not(:disabled) {
      background: var(--accent);
    }

    .send-circle:disabled {
      opacity: 0.55;
      cursor: not-allowed;
    }

    /* Suggestion Cards */
    .suggestions-grid {
      display: grid;
      grid-template-columns: repeat(4, minmax(0, 1fr));
      gap: 10px;
      margin-top: 2px;
    }

    .suggestion-card {
      background: var(--bg-surface);
      border: 1px solid var(--border);
      border-radius: 12px;
      padding: 13px 13px 14px;
      text-align: left;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      gap: 6px;
      transition: border-color 0.15s ease, background 0.15s ease;
    }

    .suggestion-card:hover {
      border-color: var(--border-strong);
      background: #fffdfb;
    }

    .suggestion-icon {
      width: 24px;
      height: 24px;
      border-radius: 7px;
      background: var(--bg-subtle);
      color: var(--text-secondary);
      font-size: 12px;
      display: grid;
      place-items: center;
      margin-bottom: 2px;
    }

    .suggestion-title {
      font-size: 12.5px;
      font-weight: 600;
      color: var(--text-primary);
    }

    .suggestion-sub {
      font-size: 11.5px;
      line-height: 1.4;
      color: var(--text-secondary);
    }

    .disclaimer {
      font-size: 11px;
      color: var(--text-muted);
      margin-top: 2px;
    }

    /* Messages */
    .msg-user {
      align-self: flex-end;
      max-width: 82%;
      background: var(--bg-subtle);
      border: 1px solid var(--border);
      color: var(--text-primary);
      padding: 10px 15px;
      border-radius: 14px;
      font-size: 13.5px;
      line-height: 1.5;
      white-space: pre-wrap;
    }

    .msg-bot {
      font-size: 14px;
      line-height: 1.65;
      color: var(--text-primary);
      background: var(--bg-surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 16px 18px;
    }

    .msg-bot h1, .msg-bot h2, .msg-bot h3 {
      font-size: 15px;
      font-weight: 600;
      margin: 14px 0 6px;
    }

    .msg-bot p {
      margin: 0 0 10px;
    }

    .msg-bot ul, .msg-bot ol {
      margin: 6px 0 12px;
      padding-left: 20px;
    }

    .msg-bot li {
      margin-bottom: 5px;
    }

    .msg-bot code {
      font-family: "JetBrains Mono", monospace;
      font-size: 12px;
      background: var(--bg-subtle);
      padding: 1px 5px;
      border-radius: 4px;
    }

    .msg-bot pre {
      font-family: "JetBrains Mono", monospace;
      font-size: 12px;
      line-height: 1.5;
      background: #f6f3ec;
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 12px;
      overflow-x: auto;
      margin: 10px 0;
    }

    .msg-bot pre code {
      background: none;
      padding: 0;
    }

    .msg-meta-row {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
      margin-top: 10px;
      font-size: 11px;
      color: var(--text-muted);
    }

    .tag-btn {
      background: var(--bg-subtle);
      border: 1px solid var(--border);
      color: var(--text-secondary);
      font-size: 11px;
      padding: 3px 8px;
      border-radius: 6px;
      cursor: pointer;
    }

    .tag-btn.active {
      border-color: var(--accent);
      color: var(--accent);
      font-weight: 500;
    }

    /* Modal */
    .modal-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(26, 25, 24, 0.35);
      display: none;
      align-items: center;
      justify-content: center;
      padding: 20px;
      z-index: 90;
    }

    .modal-backdrop.open {
      display: flex;
    }

    .modal-card {
      width: 100%;
      max-width: 500px;
      background: var(--bg-surface);
      border: 1px solid var(--border);
      border-radius: 14px;
      padding: 18px 20px;
      box-shadow: 0 18px 40px rgba(26, 25, 24, 0.16);
      display: flex;
      flex-direction: column;
      gap: 12px;
      max-height: 85vh;
      overflow-y: auto;
    }

    .modal-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .modal-title {
      margin: 0;
      font-size: 16px;
      font-weight: 600;
    }

    .field-row {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .field-lbl {
      font-size: 12px;
      color: var(--text-secondary);
      font-weight: 500;
    }

    .field-inp, .field-sel, .field-area {
      width: 100%;
      background: var(--bg-main);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 8px 10px;
      font-size: 12.5px;
      color: var(--text-primary);
      font-family: inherit;
      outline: none;
    }

    .field-area {
      min-height: 80px;
      font-family: "JetBrains Mono", monospace;
      resize: vertical;
    }

    .btn-save {
      background: var(--accent);
      color: #fff;
      border: none;
      border-radius: 8px;
      padding: 8px 14px;
      font-size: 12.5px;
      font-weight: 500;
      cursor: pointer;
      align-self: flex-end;
    }

    .btn-save:hover {
      background: var(--accent-hover);
    }

    .toast-note {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: var(--text-primary);
      color: #fff;
      font-size: 12px;
      padding: 8px 14px;
      border-radius: 8px;
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.15s ease;
      z-index: 100;
    }

    .toast-note.show {
      opacity: 1;
    }

    @media (max-width: 860px) {
      .app, .app.rail-closed {
        grid-template-columns: 1fr;
      }
      .sidebar {
        display: none;
      }
      .suggestions-grid {
        grid-template-columns: repeat(2, minmax(0, 1fr));
      }
      .hero-heading {
        font-size: 36px;
      }
    }
  </style>
</head>
<body>
  <div class="app" id="app">
    <aside class="sidebar">
      <div class="brand-header">
        <div class="brand-logo">
          <span class="brand-asterisk">✳</span>
          <span>Eve AI</span>
        </div>
        <button type="button" class="icon-action" id="close-rail-btn" title="Recolher barra lateral">◧</button>
      </div>

      <button type="button" class="new-chat-btn" id="new-chat-btn">
        <span>+</span>
        <span>Nova conversa</span>
      </button>

      <div class="search-box">
        <span>⌕</span>
        <input type="text" id="search-conv-input" placeholder="Buscar conversas" />
      </div>

      <div class="section-label">Conversas</div>
      <div class="conv-list" id="conv-list"></div>

      <div class="profile-footer" id="profile-footer">
        <div class="profile-left">
          <div class="profile-avatar" id="avatar-initials">NG</div>
          <div class="profile-text">
            <div class="profile-title" id="profile-display">Niko Goat · Free</div>
            <div class="profile-email" id="email-display">nikogoat90@gmail.com</div>
          </div>
        </div>
        <span class="chevron-up">⌃</span>
      </div>
    </aside>

    <div class="account-popover" id="account-popover">
      <div class="popover-email" id="popover-email">nikogoat90@gmail.com</div>
      <button type="button" class="popover-item" id="menu-settings">
        <span class="popover-item-main"><span>⚙</span><span>Configurações</span></span>
        <span class="popover-hint">Ctrl+Shift+,</span>
      </button>
      <button type="button" class="popover-item" id="menu-language">
        <span class="popover-item-main"><span>🌐</span><span>Idioma</span></span>
        <span class="popover-hint" id="popover-lang-label">Português (Brasil)</span>
      </button>
      <button type="button" class="popover-item" id="menu-help">
        <span class="popover-item-main"><span>?</span><span>Receber ajuda</span></span>
      </button>
      <button type="button" class="popover-item" id="menu-more">
        <span class="popover-item-main"><span>ⓘ</span><span>Saiba mais</span></span>
        <span class="popover-hint">›</span>
      </button>
      <div class="popover-sep"></div>
      <button type="button" class="popover-item" id="menu-upgrade">
        <span class="popover-item-main"><span>✦</span><span>Subir de plano</span></span>
        <span class="popover-hint" id="popover-plan-hint">Free</span>
      </button>
      <button type="button" class="popover-item" id="menu-apps">
        <span class="popover-item-main"><span>⊞</span><span>Obter apps e extensões</span></span>
      </button>
      <button type="button" class="popover-item" id="menu-keys">
        <span class="popover-item-main"><span>🔑</span><span>Obter chaves de API</span></span>
        <span class="popover-hint">↗</span>
      </button>
      <div class="popover-sep"></div>
      <button type="button" class="popover-item" id="menu-logout">
        <span class="popover-item-main"><span>↪</span><span>Sair</span></span>
      </button>
    </div>

    <div class="main">
      <div class="top-bar-mini">
        <button type="button" class="icon-action" id="open-rail-btn" style="display: none;" title="Abrir barra lateral">◧</button>
        <span style="font-size: 11.5px; color: var(--text-muted); margin-left: auto;">${modelLabel}</span>
      </div>

      <main class="scroll-main" id="scroll-main">
        <div class="center-col" id="center-col"></div>
      </main>
    </div>
  </div>

  <div class="modal-backdrop" id="modal-backdrop">
    <div class="modal-card" id="modal-card"></div>
  </div>

  <div class="toast-note" id="toast-note"></div>

  <script>
    const STORE_KEY = "eve_ai_warm_studio_v6";

    const appEl = document.getElementById("app");
    const closeRailBtn = document.getElementById("close-rail-btn");
    const openRailBtn = document.getElementById("open-rail-btn");
    const newChatBtn = document.getElementById("new-chat-btn");
    const searchConvInput = document.getElementById("search-conv-input");
    const convListEl = document.getElementById("conv-list");
    const profileFooter = document.getElementById("profile-footer");
    const accountPopover = document.getElementById("account-popover");
    const centerCol = document.getElementById("center-col");
    const scrollMain = document.getElementById("scroll-main");
    const modalBackdrop = document.getElementById("modal-backdrop");
    const modalCard = document.getElementById("modal-card");
    const toastNote = document.getElementById("toast-note");

    function showToast(text) {
      toastNote.textContent = text;
      toastNote.classList.add("show");
      setTimeout(() => toastNote.classList.remove("show"), 1600);
    }

    function defaultState() {
      return {
        searchQuery: "",
        modelProfile: "Eve Automático",
        mode: "architecture",
        activeConvId: "conv-1",
        conversations: [
          {
            id: "conv-1",
            title: "Nova conversa",
            messages: [],
          },
        ],
        account: {
          name: "Niko Goat",
          email: "nikogoat90@gmail.com",
          plan: "Free",
          language: "Português (Brasil)",
          signedIn: true,
        },
        personalization: {
          profileName: "Niko",
          roleTitle: "Engenharia e Criação",
          responseStyle: "balanced",
          customInstructions: "Responda com clareza, objetividade e exemplos úteis.",
        },
        plugins: [
          { id: "pl-1", name: "Audit Pipeline", desc: "Revisa lógica, clareza e casos de borda.", enabled: true },
          { id: "pl-2", name: "Code Helper", desc: "Estrutura funções e exemplos práticos em código.", enabled: true },
          { id: "pl-3", name: "Summary Engine", desc: "Condensa textos longos em pontos essenciais.", enabled: true },
        ],
        apiConfig: {
          executorModel: "gpt-4o-mini",
          auditorModel: "claude-3-7-sonnet-latest",
        },
      };
    }

    function loadState() {
      try {
        const raw = localStorage.getItem(STORE_KEY);
        if (!raw) return defaultState();
        const parsed = JSON.parse(raw);
        const def = defaultState();
        return {
          ...def,
          ...parsed,
          account: { ...def.account, ...(parsed.account || {}) },
          personalization: { ...def.personalization, ...(parsed.personalization || {}) },
          apiConfig: { ...def.apiConfig, ...(parsed.apiConfig || {}) },
        };
      } catch {
        return defaultState();
      }
    }

    function saveState() {
      try {
        localStorage.setItem(STORE_KEY, JSON.stringify(state));
      } catch {}
    }

    let state = loadState();
    let draftPrompt = "";

    function getActiveConv() {
      return state.conversations.find((c) => c.id === state.activeConvId) || state.conversations[0];
    }

    function escapeHtml(s) {
      return String(s || "")
        .replace(/&/g, "&amp;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;")
        .replace(/"/g, "&quot;");
    }

    function fmtInline(s) {
      return s
        .replace(/\*\*([^*]+)\*\*/g, "<strong>$1</strong>")
        .replace(/\`([^\`]+)\`/g, "<code>$1</code>");
    }

    function renderMarkdown(raw) {
      const esc = escapeHtml(raw);
      const blocks = [];
      const tok = esc.replace(/\`\`\`([a-zA-Z0-9_-]*)\n([\s\S]*?)\`\`\`/g, function (_m, _l, code) {
        const i = blocks.length;
        blocks.push("<pre><code>" + code.trim() + "</code></pre>");
        return "%%CODE_" + i + "%%";
      });

      const lines = tok.split("\n");
      const out = [];
      let inList = false;

      for (const line of lines) {
        if (/^-\s+/.test(line) || /^\d+\.\s+/.test(line)) {
          if (!inList) {
            out.push("<ul>");
            inList = true;
          }
          out.push("<li>" + fmtInline(line.replace(/^-\s+/, "").replace(/^\d+\.\s+/, "")) + "</li>");
          continue;
        }
        if (inList) {
          out.push("</ul>");
          inList = false;
        }
        if (line.startsWith("### ")) out.push("<h3>" + fmtInline(line.slice(4)) + "</h3>");
        else if (line.startsWith("## ")) out.push("<h2>" + fmtInline(line.slice(3)) + "</h2>");
        else if (line.startsWith("# ")) out.push("<h1>" + fmtInline(line.slice(2)) + "</h1>");
        else if (!line.trim()) out.push("");
        else out.push("<p>" + fmtInline(line) + "</p>");
      }

      if (inList) out.push("</ul>");
      let html = out.join("\n");
      blocks.forEach((b, i) => {
        html = html.replace("%%CODE_" + i + "%%", b);
      });
      return html;
    }

    function stageText(msg) {
      if (!msg.stages) return msg.content;
      if (msg.stageView === "execution") return msg.stages.execution?.content || msg.content;
      if (msg.stageView === "audit") return msg.stages.audit?.content || msg.content;
      return msg.content;
    }

    function syncSidebarAndAccount() {
      const words = (state.account.name || "NG").trim().split(/\s+/).filter(Boolean);
      const initials = words.slice(0, 2).map((w) => w[0].toUpperCase()).join("") || "NG";
      document.getElementById("avatar-initials").textContent = initials;
      document.getElementById("profile-display").textContent =
        (state.account.signedIn ? state.account.name : "Sessão encerrada") + " · " + state.account.plan;
      document.getElementById("email-display").textContent = state.account.email;
      document.getElementById("popover-email").textContent = state.account.email;
      document.getElementById("popover-lang-label").textContent = state.account.language;
      document.getElementById("popover-plan-hint").textContent = state.account.plan;

      const q = (state.searchQuery || "").trim().toLowerCase();
      const list = state.conversations.filter(
        (c) =>
          !q ||
          c.title.toLowerCase().includes(q) ||
          c.messages.some((m) => String(m.content).toLowerCase().includes(q))
      );

      convListEl.innerHTML = "";
      if (list.length === 0) {
        const empty = document.createElement("div");
        empty.className = "conv-empty";
        empty.textContent = "Nenhuma conversa ainda.";
        convListEl.appendChild(empty);
        return;
      }

      list.forEach((c) => {
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "conv-item" + (c.id === state.activeConvId ? " active" : "");
        btn.textContent = c.title;
        btn.addEventListener("click", () => {
          state.activeConvId = c.id;
          saveState();
          renderWorkspace();
        });
        convListEl.appendChild(btn);
      });
    }

    function renderWorkspace() {
      syncSidebarAndAccount();
      const conv = getActiveConv();
      centerCol.innerHTML = "";

      if (conv.messages.length === 0) {
        const who = (state.personalization.profileName || "Niko").trim();
        const hero = document.createElement("div");
        hero.className = "hero-block";
        hero.innerHTML =
          "<div class='hero-eyebrow'><span>✳</span><span>EVE AI</span></div>" +
          "<h1 class='hero-heading'>O que vamos construir <em>hoje</em>, " + escapeHtml(who) + "?</h1>" +
          "<p class='hero-sub'>Escreva, programe, analise e pense em voz alta. Eve lembra do fio da conversa.</p>";
        centerCol.appendChild(hero);
      } else {
        conv.messages.forEach((msg) => {
          if (msg.role === "user") {
            const u = document.createElement("div");
            u.className = "msg-user";
            u.textContent = msg.content;
            centerCol.appendChild(u);
            return;
          }

          const b = document.createElement("div");
          b.className = "msg-bot";
          const body = document.createElement("div");
          body.innerHTML = renderMarkdown(stageText(msg));
          b.appendChild(body);

          const meta = document.createElement("div");
          meta.className = "msg-meta-row";

          const cp = document.createElement("button");
          cp.type = "button";
          cp.className = "tag-btn";
          cp.textContent = "Copiar";
          cp.addEventListener("click", async () => {
            try {
              await navigator.clipboard.writeText(stageText(msg));
              showToast("Resposta copiada");
            } catch {}
          });
          meta.appendChild(cp);

          if (msg.stages) {
            ["final", "execution", "audit"].forEach((k) => {
              const btn = document.createElement("button");
              btn.type = "button";
              btn.className = "tag-btn" + ((msg.stageView || "final") === k ? " active" : "");
              btn.textContent = k === "final" ? "Final" : k === "execution" ? "Execução" : "Auditoria";
              btn.addEventListener("click", () => {
                msg.stageView = k;
                saveState();
                renderWorkspace();
              });
              meta.appendChild(btn);
            });
          }

          const tm = document.createElement("span");
          tm.textContent = msg.time || "";
          meta.appendChild(tm);

          b.appendChild(meta);
          centerCol.appendChild(b);
        });
      }

      const card = document.createElement("div");
      card.className = "prompt-card";
      card.innerHTML =
        "<textarea id='main-prompt' class='prompt-textarea' rows='2' placeholder='Pergunte qualquer coisa à Eve...'>" + escapeHtml(draftPrompt) + "</textarea>" +
        "<div class='prompt-bottom'>" +
          "<button type='button' class='model-pill-btn' id='model-cycle-btn'><span class='model-dot'></span><span id='model-pill-text'>" + escapeHtml(state.modelProfile) + "</span><span>⌄</span></button>" +
          "<button type='button' class='send-circle' id='main-send-btn' title='Enviar'>↑</button>" +
        "</div>";
      centerCol.appendChild(card);

      if (conv.messages.length === 0) {
        const grid = document.createElement("div");
        grid.className = "suggestions-grid";

        const suggestions = [
          {
            icon: "✎",
            title: "Escrever",
            sub: "Um e-mail difícil de recusar",
            prompt: "Escreva um e-mail educado, firme e difícil de recusar para renegociar prazos de entrega.",
            mode: "architecture",
          },
          {
            icon: "&lt;/&gt;",
            title: "Programar",
            sub: "Uma função em JavaScript",
            prompt: "Crie uma função limpa e segura em JavaScript para debounce com cancelamento e tratamento de erros.",
            mode: "implementation",
          },
          {
            icon: "📄",
            title: "Analisar",
            sub: "Resuma um texto longo",
            prompt: "Resuma os pontos principais, decisões e próximos passos de um documento técnico longo.",
            mode: "code-review",
          },
          {
            icon: "🎓",
            title: "Aprender",
            sub: "Explique de forma simples",
            prompt: "Explique de forma simples como funciona uma fila assíncrona com retries e idempotência.",
            mode: "architecture",
          },
        ];

        suggestions.forEach((s) => {
          const btn = document.createElement("button");
          btn.type = "button";
          btn.className = "suggestion-card";
          btn.innerHTML =
            "<div class='suggestion-icon'>" + s.icon + "</div>" +
            "<div class='suggestion-title'>" + escapeHtml(s.title) + "</div>" +
            "<div class='suggestion-sub'>" + escapeHtml(s.sub) + "</div>";
          btn.addEventListener("click", () => {
            state.mode = s.mode;
            draftPrompt = s.prompt;
            renderWorkspace();
            const ta = document.getElementById("main-prompt");
            if (ta) ta.focus();
          });
          grid.appendChild(btn);
        });

        centerCol.appendChild(grid);

        const disc = document.createElement("div");
        disc.className = "disclaimer";
        disc.textContent = "Eve pode cometer erros. Confira informações importantes.";
        centerCol.appendChild(disc);
      }

      const ta = document.getElementById("main-prompt");
      const sendBtn = document.getElementById("main-send-btn");
      const modelBtn = document.getElementById("model-cycle-btn");

      function updateSendReady() {
        if (!ta || !sendBtn) return;
        sendBtn.classList.toggle("ready", ta.value.trim().length > 0);
      }

      if (ta) {
        ta.addEventListener("input", () => {
          draftPrompt = ta.value;
          ta.style.height = "auto";
          ta.style.height = Math.min(ta.scrollHeight, 180) + "px";
          updateSendReady();
        });
        ta.addEventListener("keydown", (e) => {
          if (e.key === "Enter" && !e.shiftKey) {
            e.preventDefault();
            submitPrompt(ta.value);
          }
        });
        updateSendReady();
      }

      if (sendBtn) {
        sendBtn.addEventListener("click", () => {
          submitPrompt(ta ? ta.value : "");
        });
      }

      if (modelBtn) {
        const profiles = ["Eve Automático", "Eve Preciso", "Eve Rápido"];
        modelBtn.addEventListener("click", () => {
          const idx = profiles.indexOf(state.modelProfile);
          state.modelProfile = profiles[(idx + 1) % profiles.length];
          saveState();
          renderWorkspace();
        });
      }

      scrollMain.scrollTop = scrollMain.scrollHeight;
    }

    async function submitPrompt(raw) {
      const clean = (raw || "").trim();
      if (!clean) return;

      if (!state.account.signedIn) {
        state.account.signedIn = true;
        saveState();
      }

      const conv = getActiveConv();
      if (conv.title === "Nova conversa") {
        conv.title = clean.slice(0, 42);
      }

      conv.messages.push({ role: "user", content: clean, time: "agora" });
      draftPrompt = "";
      saveState();
      renderWorkspace();

      const pending = document.createElement("div");
      pending.className = "msg-bot";
      pending.style.color = "var(--text-muted)";
      pending.textContent = "Pensando...";
      centerCol.appendChild(pending);
      scrollMain.scrollTop = scrollMain.scrollHeight;

      try {
        const activePlugins = state.plugins.filter((p) => p.enabled).map((p) => p.name);
        const res = await fetch("/api/run", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            mode: state.mode,
            prompt: clean,
            modelProfile: state.modelProfile,
            language: state.account.language,
            personalization: state.personalization,
            enabledPlugins: activePlugins,
          }),
        });
        const data = await res.json();
        pending.remove();

        if (!res.ok) {
          conv.messages.push({
            role: "assistant",
            content: data.error || "Erro ao processar.",
            stages: null,
            stageView: "final",
            time: "erro",
          });
        } else {
          const ms = (data.stages?.execution?.durationMs || 0) + (data.stages?.audit?.durationMs || 0);
          conv.messages.push({
            role: "assistant",
            content: data.finalOutput,
            stages: data.stages,
            stageView: "final",
            time: ms + " ms",
          });
        }
      } catch (err) {
        pending.remove();
        conv.messages.push({
          role: "assistant",
          content: "Falha de conexão: " + (err instanceof Error ? err.message : String(err)),
          stages: null,
          stageView: "final",
          time: "erro",
        });
      } finally {
        saveState();
        renderWorkspace();
      }
    }

    function openModal(html) {
      modalCard.innerHTML = html;
      modalBackdrop.classList.add("open");
    }

    function closeModal() {
      modalBackdrop.classList.remove("open");
    }

    modalBackdrop.addEventListener("click", (e) => {
      if (e.target === modalBackdrop) closeModal();
    });

    function togglePopover(force) {
      const next = typeof force === "boolean" ? force : !accountPopover.classList.contains("open");
      accountPopover.classList.toggle("open", next);
    }

    profileFooter.addEventListener("click", (e) => {
      e.stopPropagation();
      togglePopover();
    });

    document.addEventListener("click", (e) => {
      if (!accountPopover.contains(e.target) && !profileFooter.contains(e.target)) {
        togglePopover(false);
      }
    });

    function openSettingsModal() {
      togglePopover(false);
      openModal(
        "<div class='modal-top'><h2 class='modal-title'>Configurações</h2><button type='button' class='icon-action' id='m-close'>✕</button></div>" +
        "<div class='field-row'><label class='field-lbl'>Nome</label><input id='m-acc-name' class='field-inp' value='" + escapeHtml(state.account.name) + "' /></div>" +
        "<div class='field-row'><label class='field-lbl'>E-mail</label><input id='m-acc-email' class='field-inp' value='" + escapeHtml(state.account.email) + "' /></div>" +
        "<div class='field-row'><label class='field-lbl'>Como a Eve chama você</label><input id='m-pers-name' class='field-inp' value='" + escapeHtml(state.personalization.profileName) + "' /></div>" +
        "<div class='field-row'><label class='field-lbl'>Estilo de resposta</label><select id='m-pers-style' class='field-sel'>" +
          "<option value='concise'" + (state.personalization.responseStyle === "concise" ? " selected" : "") + ">Conciso</option>" +
          "<option value='balanced'" + (state.personalization.responseStyle === "balanced" ? " selected" : "") + ">Equilibrado</option>" +
          "<option value='detailed'" + (state.personalization.responseStyle === "detailed" ? " selected" : "") + ">Detalhado</option>" +
        "</select></div>" +
        "<div class='field-row'><label class='field-lbl'>Instruções personalizadas</label><textarea id='m-pers-inst' class='field-area'>" + escapeHtml(state.personalization.customInstructions) + "</textarea></div>" +
        "<button type='button' class='btn-save' id='m-save-settings'>Salvar</button>"
      );
      document.getElementById("m-close").addEventListener("click", closeModal);
      document.getElementById("m-save-settings").addEventListener("click", () => {
        state.account.name = document.getElementById("m-acc-name").value.trim() || "Niko Goat";
        state.account.email = document.getElementById("m-acc-email").value.trim() || "nikogoat90@gmail.com";
        state.personalization.profileName = document.getElementById("m-pers-name").value.trim() || "Niko";
        state.personalization.responseStyle = document.getElementById("m-pers-style").value;
        state.personalization.customInstructions = document.getElementById("m-pers-inst").value;
        saveState();
        renderWorkspace();
        closeModal();
        showToast("Configurações salvas");
      });
    }

    document.getElementById("menu-settings").addEventListener("click", openSettingsModal);

    document.getElementById("menu-language").addEventListener("click", () => {
      togglePopover(false);
      openModal(
        "<div class='modal-top'><h2 class='modal-title'>Idioma</h2><button type='button' class='icon-action' id='m-close'>✕</button></div>" +
        "<div class='field-row'><label class='field-lbl'>Selecione o idioma da interface e respostas</label><select id='m-lang-sel' class='field-sel'>" +
          "<option value='Português (Brasil)'" + (state.account.language === "Português (Brasil)" ? " selected" : "") + ">Português (Brasil)</option>" +
          "<option value='English (US)'" + (state.account.language === "English (US)" ? " selected" : "") + ">English (US)</option>" +
          "<option value='Español'" + (state.account.language === "Español" ? " selected" : "") + ">Español</option>" +
        "</select></div>" +
        "<button type='button' class='btn-save' id='m-save-lang'>Aplicar idioma</button>"
      );
      document.getElementById("m-close").addEventListener("click", closeModal);
      document.getElementById("m-save-lang").addEventListener("click", () => {
        state.account.language = document.getElementById("m-lang-sel").value;
        saveState();
        syncSidebarAndAccount();
        closeModal();
        showToast("Idioma: " + state.account.language);
      });
    });

    document.getElementById("menu-help").addEventListener("click", () => {
      togglePopover(false);
      openModal(
        "<div class='modal-top'><h2 class='modal-title'>Receber ajuda</h2><button type='button' class='icon-action' id='m-close'>✕</button></div>" +
        "<p style='margin:0;font-size:13px;color:var(--text-secondary);line-height:1.5;'>" +
        "• <strong>Nova conversa:</strong> limpa o fio atual ou cria um novo.<br/>" +
        "• <strong>Enter:</strong> envia a mensagem (<strong>Shift+Enter</strong> quebra linha).<br/>" +
        "• <strong>Ctrl+Shift+,:</strong> abre as configurações da conta e personalização." +
        "</p>"
      );
      document.getElementById("m-close").addEventListener("click", closeModal);
    });

    document.getElementById("menu-more").addEventListener("click", () => {
      togglePopover(false);
      openModal(
        "<div class='modal-top'><h2 class='modal-title'>Saiba mais</h2><button type='button' class='icon-action' id='m-close'>✕</button></div>" +
        "<p style='margin:0;font-size:13px;color:var(--text-secondary);line-height:1.5;'>" +
        "A <strong>Eve AI</strong> opera com pipeline de execução e auditoria em Node.js + TypeScript, com persistência local no navegador e suporte a provedores configuráveis via <code>.env</code>." +
        "</p>"
      );
      document.getElementById("m-close").addEventListener("click", closeModal);
    });

    document.getElementById("menu-upgrade").addEventListener("click", () => {
      togglePopover(false);
      openModal(
        "<div class='modal-top'><h2 class='modal-title'>Subir de plano</h2><button type='button' class='icon-action' id='m-close'>✕</button></div>" +
        "<div class='field-row'><label class='field-lbl'>Plano atual: " + escapeHtml(state.account.plan) + "</label><select id='m-plan-sel' class='field-sel'>" +
          "<option value='Free'" + (state.account.plan === "Free" ? " selected" : "") + ">Free</option>" +
          "<option value='Pro'" + (state.account.plan === "Pro" ? " selected" : "") + ">Pro</option>" +
          "<option value='Max'" + (state.account.plan === "Max" ? " selected" : "") + ">Max</option>" +
        "</select></div>" +
        "<button type='button' class='btn-save' id='m-save-plan'>Confirmar plano</button>"
      );
      document.getElementById("m-close").addEventListener("click", closeModal);
      document.getElementById("m-save-plan").addEventListener("click", () => {
        state.account.plan = document.getElementById("m-plan-sel").value;
        saveState();
        syncSidebarAndAccount();
        closeModal();
        showToast("Plano atualizado para " + state.account.plan);
      });
    });

    document.getElementById("menu-apps").addEventListener("click", () => {
      togglePopover(false);
      const rows = state.plugins
        .map(
          (p) =>
            "<div style='display:flex;align-items:center;justify-content:space-between;padding:8px 10px;border:1px solid var(--border);border-radius:8px;'>" +
            "<div><div style='font-size:12.5px;font-weight:600;'>" + escapeHtml(p.name) + "</div><div style='font-size:11.5px;color:var(--text-secondary);'>" + escapeHtml(p.desc) + "</div></div>" +
            "<button type='button' class='tag-btn " + (p.enabled ? "active" : "") + "' data-pl-id='" + escapeHtml(p.id) + "'>" + (p.enabled ? "Ativo" : "Inativo") + "</button>" +
            "</div>"
        )
        .join("");

      openModal(
        "<div class='modal-top'><h2 class='modal-title'>Obter apps e extensões</h2><button type='button' class='icon-action' id='m-close'>✕</button></div>" +
        "<div style='display:flex;flex-direction:column;gap:8px;'>" + rows + "</div>"
      );
      document.getElementById("m-close").addEventListener("click", closeModal);
      modalCard.querySelectorAll("[data-pl-id]").forEach((btn) => {
        btn.addEventListener("click", () => {
          const id = btn.getAttribute("data-pl-id");
          const target = state.plugins.find((x) => x.id === id);
          if (target) {
            target.enabled = !target.enabled;
            saveState();
            document.getElementById("menu-apps").click();
          }
        });
      });
    });

    document.getElementById("menu-keys").addEventListener("click", () => {
      togglePopover(false);
      const envSample =
        "EXECUTOR_API_KEY=sk-sua-chave-openai\nEXECUTOR_MODEL=" +
        state.apiConfig.executorModel +
        "\nAUDITOR_API_KEY=sk-ant-sua-chave-anthropic\nAUDITOR_MODEL=" +
        state.apiConfig.auditorModel;

      openModal(
        "<div class='modal-top'><h2 class='modal-title'>Obter chaves de API</h2><button type='button' class='icon-action' id='m-close'>✕</button></div>" +
        "<p style='margin:0;font-size:12px;color:var(--text-secondary);'>Configure estas variáveis no arquivo <code>.env</code> na raiz do projeto:</p>" +
        "<pre style='margin:0;background:#f6f3ec;border:1px solid var(--border);padding:10px;border-radius:8px;font-size:11.5px;overflow:auto;'>" + escapeHtml(envSample) + "</pre>" +
        "<button type='button' class='btn-save' id='m-copy-env'>Copiar exemplo .env</button>"
      );
      document.getElementById("m-close").addEventListener("click", closeModal);
      document.getElementById("m-copy-env").addEventListener("click", async () => {
        try {
          await navigator.clipboard.writeText(envSample);
          showToast("Exemplo .env copiado");
        } catch {}
      });
    });

    document.getElementById("menu-logout").addEventListener("click", () => {
      togglePopover(false);
      state.account.signedIn = !state.account.signedIn;
      saveState();
      syncSidebarAndAccount();
      showToast(state.account.signedIn ? "Sessão iniciada" : "Sessão encerrada");
    });

    newChatBtn.addEventListener("click", () => {
      const fresh = {
        id: "conv-" + Date.now(),
        title: "Nova conversa",
        messages: [],
      };
      state.conversations.unshift(fresh);
      state.activeConvId = fresh.id;
      draftPrompt = "";
      saveState();
      renderWorkspace();
    });

    searchConvInput.addEventListener("input", () => {
      state.searchQuery = searchConvInput.value;
      saveState();
      syncSidebarAndAccount();
    });

    closeRailBtn.addEventListener("click", () => {
      appEl.classList.add("rail-closed");
      openRailBtn.style.display = "inline-flex";
    });

    openRailBtn.addEventListener("click", () => {
      appEl.classList.remove("rail-closed");
      openRailBtn.style.display = "none";
    });

    document.addEventListener("keydown", (e) => {
      if (e.key === "Escape") {
        togglePopover(false);
        closeModal();
      }
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key === ",") {
        e.preventDefault();
        openSettingsModal();
      }
    });

    renderWorkspace();
  </script>
</body>
</html>`;
}

const eve = createEve();
const port = Number(process.env.PORT) || 3001;
const htmlPage = buildHtmlPage(eve.modelLabel);

const server = http.createServer(async (req, res) => {
  if (req.method === "GET" && req.url === "/") {
    res.writeHead(200, { "Content-Type": "text/html; charset=utf-8" });
    res.end(htmlPage);
    return;
  }

  if (req.method === "POST" && req.url === "/api/run") {
    let raw = "";
    for await (const chunk of req) {
      raw += chunk;
    }

    try {
      const body = JSON.parse(raw || "{}") as Partial<EveRequest>;
      const mode: TaskMode =
        body.mode === "implementation" || body.mode === "code-review"
          ? body.mode
          : "architecture";

      const result = await eve.orchestrator.run({
        mode,
        prompt: body.prompt ?? "",
        modelProfile: body.modelProfile,
        language: body.language,
        context: body.context,
        personalization: body.personalization,
        enabledPlugins: body.enabledPlugins,
      });

      res.writeHead(200, { "Content-Type": "application/json; charset=utf-8" });
      res.end(JSON.stringify(result));
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erro ao processar";
      res.writeHead(400, { "Content-Type": "application/json; charset=utf-8" });
      res.end(JSON.stringify({ error: message }));
    }
    return;
  }

  res.writeHead(404, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Não encontrado");
});

server.on("error", (err: NodeJS.ErrnoException) => {
  if (err.code === "EADDRINUSE") {
    console.error(
      `Porta ${port} já está em uso. Rode com outra porta, ex.: PORT=3002 npm run web`
    );
    process.exitCode = 1;
    return;
  }
  throw err;
});

server.listen(port, () => {
  console.log(`Eve AI rodando em http://localhost:${port}`);
});
