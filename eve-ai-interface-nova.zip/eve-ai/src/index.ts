import "dotenv/config";
import { EveOrchestrator } from "./core/orchestrator.js";
import { AnthropicMessagesProvider, OpenAICompatibleProvider } from "./providers/llm-provider.js";
import { MockProvider } from "./providers/mock-provider.js";

function createProviders() {
  const executorKey = process.env.EXECUTOR_API_KEY?.trim();
  const auditorKey = process.env.AUDITOR_API_KEY?.trim();

  if (!executorKey || !auditorKey) {
    return {
      executorProvider: new MockProvider("mock-openai-executor", "executor"),
      auditorProvider: new MockProvider("mock-anthropic-auditor", "auditor"),
    };
  }

  return {
    executorProvider: new OpenAICompatibleProvider({
      name: "openai-executor",
      apiKey: executorKey,
      baseUrl: process.env.EXECUTOR_BASE_URL ?? "https://api.openai.com/v1",
      model: process.env.EXECUTOR_MODEL ?? "gpt-4o-mini",
    }),
    auditorProvider: new AnthropicMessagesProvider({
      name: "anthropic-auditor",
      apiKey: auditorKey,
      baseUrl: process.env.AUDITOR_BASE_URL ?? "https://api.anthropic.com/v1",
      model: process.env.AUDITOR_MODEL ?? "claude-3-7-sonnet-latest",
    }),
  };
}

async function main(): Promise<void> {
  const eve = new EveOrchestrator(createProviders());
  const result = await eve.run({
    mode: "architecture",
    prompt: "Projete um serviço de processamento de webhooks com fila, retries e idempotência.",
    context: "Node.js + TypeScript",
  });
  console.log(result.finalOutput);
}

main().catch((err: unknown) => {
  console.error("Erro ao executar a EVE AI:", err);
  process.exitCode = 1;
});
