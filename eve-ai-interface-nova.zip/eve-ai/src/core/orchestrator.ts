import {
  AUDITOR_SYSTEM_PROMPT,
  EXECUTOR_SYSTEM_PROMPT,
  buildAuditorUserPrompt,
  buildExecutorUserPrompt,
} from "../prompts/engineering.js";
import { EveRequest, EveResponse, LLMProvider, StageResult } from "../types/eve.js";

export interface EveOrchestratorConfig {
  executorProvider: LLMProvider;
  auditorProvider: LLMProvider;
}

export class EveOrchestrator {
  private readonly executorProvider: LLMProvider;
  private readonly auditorProvider: LLMProvider;

  constructor(config: EveOrchestratorConfig) {
    this.executorProvider = config.executorProvider;
    this.auditorProvider = config.auditorProvider;
  }

  public async run(request: EveRequest): Promise<EveResponse> {
    const prompt = request.prompt.trim();
    if (!prompt) {
      throw new Error("O campo 'prompt' não pode estar vazio.");
    }

    const execution = await this.runStage({
      role: "executor",
      provider: this.executorProvider,
      systemPrompt: EXECUTOR_SYSTEM_PROMPT,
      userPrompt: buildExecutorUserPrompt({
        mode: request.mode,
        prompt,
        context: request.context,
        modelProfile: request.modelProfile,
        language: request.language,
        personalization: request.personalization,
        enabledPlugins: request.enabledPlugins,
      }),
      temperature: 0.2,
    });

    const audit = await this.runStage({
      role: "auditor",
      provider: this.auditorProvider,
      systemPrompt: AUDITOR_SYSTEM_PROMPT,
      userPrompt: buildAuditorUserPrompt({
        mode: request.mode,
        originalPrompt: prompt,
        context: request.context,
        executionOutput: execution.content,
        modelProfile: request.modelProfile,
        language: request.language,
        personalization: request.personalization,
        enabledPlugins: request.enabledPlugins,
      }),
      temperature: 0.3,
    });

    return {
      mode: request.mode,
      finalOutput: audit.content,
      stages: {
        execution,
        audit,
      },
    };
  }

  private async runStage(params: {
    role: "executor" | "auditor";
    provider: LLMProvider;
    systemPrompt: string;
    userPrompt: string;
    temperature: number;
  }): Promise<StageResult> {
    const start = performance.now();
    const content = await params.provider.complete({
      systemPrompt: params.systemPrompt,
      userPrompt: params.userPrompt,
      temperature: params.temperature,
    });
    const durationMs = Math.round(performance.now() - start);

    return {
      role: params.role,
      providerName: params.provider.name,
      content,
      durationMs,
    };
  }
}
