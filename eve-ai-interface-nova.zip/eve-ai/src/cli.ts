import "dotenv/config";
import readline from "node:readline/promises";
import { stdin as input, stdout as output } from "node:process";
import { EveOrchestrator } from "./core/orchestrator.js";
import { AnthropicMessagesProvider, OpenAICompatibleProvider } from "./providers/llm-provider.js";
import { MockProvider } from "./providers/mock-provider.js";
import { TaskMode } from "./types/eve.js";

function buildEve() {
  const executorKey = process.env.EXECUTOR_API_KEY?.trim();
  const auditorKey = process.env.AUDITOR_API_KEY?.trim();

  if (!executorKey || !auditorKey) {
    return new EveOrchestrator({
      executorProvider: new MockProvider("mock-openai-executor", "executor"),
      auditorProvider: new MockProvider("mock-anthropic-auditor", "auditor"),
    });
  }

  return new EveOrchestrator({
    executorProvider: new OpenAICompatibleProvider({
      name: "openai-executor",
      apiKey: executorKey,
      baseUrl: process.env.EXECUTOR_BASE_URL ?? "https://api.openai.com/v1",
      model: process.env.EXECUTOR_MODEL ?? "gpt-4o-mini",
    }),
    auditorProvider: new AnthropicMessagesProvider({
      name: "anthropic-auditor",
      apiKey: auditorKey,
      baseUrl: process.env.AUDITOR_BASE_URL ?? "https://api.anthropic.com/v1",
      model: process.env.AUDITOR_MODEL ?? "claude-3-7-sonnet-latest",
    }),
  });
}

function parseMode(raw: string): TaskMode {
  const normalized = raw.trim().toLowerCase();
  if (normalized === "implementation" || normalized === "impl") return "implementation";
  if (normalized === "code-review" || normalized === "review") return "code-review";
  return "architecture";
}

async function runCli(): Promise<void> {
  const eve = buildEve();
  const rl = readline.createInterface({ input, output });
  console.log("EVE AI CLI iniciada. Digite 'sair' para encerrar.\n");

  try {
    while (true) {
      const modeAnswer = await rl.question("Modo [architecture | implementation | code-review]: ");
      if (modeAnswer.trim().toLowerCase() === "sair") break;

      const promptAnswer = await rl.question("Demanda técnica: ");
      if (promptAnswer.trim().toLowerCase() === "sair") break;
      if (!promptAnswer.trim()) continue;

      const contextAnswer = await rl.question("Contexto opcional (Enter para pular): ");
      if (contextAnswer.trim().toLowerCase() === "sair") break;

      const result = await eve.run({
        mode: parseMode(modeAnswer),
        prompt: promptAnswer,
        context: contextAnswer.trim() || undefined,
      });

      console.log("\n--- RESPOSTA CONSOLIDADA (EVE AI) ---\n");
      console.log(result.finalOutput);
    }
  } finally {
    rl.close();
  }
}

runCli().catch((err: unknown) => {
  console.error("Erro na CLI da EVE AI:", err);
  process.exitCode = 1;
});
