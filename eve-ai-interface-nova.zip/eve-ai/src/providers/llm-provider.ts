import { CompletionInput, LLMProvider } from "../types/eve.js";

export class OpenAICompatibleProvider implements LLMProvider {
  public readonly name: string;
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly model: string;

  constructor(options: {
    name: string;
    apiKey: string;
    baseUrl: string;
    model: string;
  }) {
    this.name = options.name;
    this.apiKey = options.apiKey;
    this.baseUrl = options.baseUrl.replace(/\/+$/, "");
    this.model = options.model;
  }

  public async complete(input: CompletionInput): Promise<string> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30_000);

    try {
      const response = await fetch(`${this.baseUrl}/chat/completions`, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${this.apiKey}`,
        },
        body: JSON.stringify({
          model: this.model,
          temperature: input.temperature ?? 0.2,
          messages: [
            { role: "system", content: input.systemPrompt },
            { role: "user", content: input.userPrompt },
          ],
        }),
      });

      if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`[${this.name}] Falha na API (${response.status}): ${errorBody}`);
      }

      const data = (await response.json()) as {
        choices?: Array<{ message?: { content?: string } }>;
      };

      const content = data.choices?.[0]?.message?.content?.trim();
      if (!content) {
        throw new Error(`[${this.name}] Resposta vazia do modelo.`);
      }

      return content;
    } finally {
      clearTimeout(timeoutId);
    }
  }
}

export class AnthropicMessagesProvider implements LLMProvider {
  public readonly name: string;
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly model: string;
  private readonly maxTokens: number;

  constructor(options: {
    name: string;
    apiKey: string;
    baseUrl?: string;
    model: string;
    maxTokens?: number;
  }) {
    this.name = options.name;
    this.apiKey = options.apiKey;
    this.baseUrl = (options.baseUrl ?? "https://api.anthropic.com/v1").replace(/\/+$/, "");
    this.model = options.model;
    this.maxTokens = options.maxTokens ?? 4096;
  }

  public async complete(input: CompletionInput): Promise<string> {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 30_000);

    try {
      const response = await fetch(`${this.baseUrl}/messages`, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          "x-api-key": this.apiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: this.model,
          max_tokens: this.maxTokens,
          temperature: input.temperature ?? 0.3,
          system: input.systemPrompt,
          messages: [{ role: "user", content: input.userPrompt }],
        }),
      });

      if (!response.ok) {
        const errorBody = await response.text();
        throw new Error(`[${this.name}] Falha na API Anthropic (${response.status}): ${errorBody}`);
      }

      const data = (await response.json()) as {
        content?: Array<{ type?: string; text?: string }>;
      };

      const content = data.content
        ?.filter((block) => block.type === "text" && typeof block.text === "string")
        .map((block) => block.text)
        .join("\n")
        .trim();

      if (!content) {
        throw new Error(`[${this.name}] Resposta vazia da API Anthropic.`);
      }

      return content;
    } finally {
      clearTimeout(timeoutId);
    }
  }
}
