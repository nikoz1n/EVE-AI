import { CompletionInput, LLMProvider } from "../types/eve.js";

export class MockProvider implements LLMProvider {
  public readonly name: string;
  private readonly roleLabel: string;

  constructor(name: string, roleLabel: string) {
    this.name = name;
    this.roleLabel = roleLabel;
  }

  public async complete(input: CompletionInput): Promise<string> {
    if (this.roleLabel === "executor") {
      return [
        "### Execução Técnica",
        "- Estrutura direta definida com validação explícita de entrada.",
        "- Fluxo principal preparado para uso imediato.",
        "",
        "```js",
        "export function formatGreeting(name) {",
        "  const clean = String(name || '').trim();",
        "  return clean ? `Olá, ${clean}` : 'Olá';",
        "}",
        "```",
      ].join("\n");
    }

    const preview = input.userPrompt.slice(0, 220).replace(/\n+/g, " ");

    return [
      "### 1. Pontos Principais",
      "- Resposta estruturada com revisão de clareza, lógica e casos de borda.",
      "- Preferências de conta, idioma e personalização aplicadas automaticamente.",
      "",
      "### 2. Resposta Consolidada",
      `Eve AI concluiu a análise para: "${preview}".`,
      "",
      "### 3. Próximos Passos",
      "- Continue a conversa no mesmo fio ou inicie uma nova conversa na barra lateral.",
    ].join("\n");
  }
}
