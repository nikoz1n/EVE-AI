export type EveRole = "executor" | "auditor";
export type TaskMode = "architecture" | "implementation" | "code-review";

export interface EveRequest {
  prompt: string;
  mode: TaskMode;
  modelProfile?: string;
  language?: string;
  context?: string;
  personalization?: {
    profileName?: string;
    roleTitle?: string;
    responseStyle?: "concise" | "balanced" | "detailed";
    customInstructions?: string;
  };
  enabledPlugins?: string[];
}

export interface StageResult {
  role: EveRole;
  providerName: string;
  content: string;
  durationMs: number;
}

export interface EveResponse {
  mode: TaskMode;
  finalOutput: string;
  stages: {
    execution: StageResult;
    audit: StageResult;
  };
}

export interface CompletionInput {
  systemPrompt: string;
  userPrompt: string;
  temperature?: number;
}

export interface LLMProvider {
  readonly name: string;
  complete(input: CompletionInput): Promise<string>;
}
